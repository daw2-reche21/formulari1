  </head>
<body>
<?php
  echo "<h3>List</h3>
        <ul>
        <li>I'v learned to use mysql belong php</li>
        <li>Mysql and php creates a dynamics html pages</li>
        <li>It's possible to make a pages linkeds with php</li>
        <li>The same code for mysql is used in php to create databases and tables</li>
        <li>Php allows to make loops to show mysql data</li>
        <li>We need an a mysql terminal to make sure the queries</li>
        <li>queries are saved in a variable called \$query</li>
        <li>Thanks to html code is possible to show the querie's results from a visual mode</li>
        <li>Extract() is a function wich extracts the columns of the querie to make easier showing it up</li>
        <li>We need gethostname() to start mysql</li>
  
  </ul>
  <p>Document: 6</p>
  <p>Teacher: 7</p>
  <p>Myself: 3</p>
  <p>Improvemts: I don't know what improvements could make easier to learn this but I know that I would need improve myself in php. ";
?>
</body>
</html>