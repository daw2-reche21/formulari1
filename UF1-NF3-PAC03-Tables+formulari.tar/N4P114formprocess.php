<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Suma</title>
</head>
<body>
<form action="N4P115formprocess.php" method="post">
    <table>
        <tr>
        <td><input type="number" name="num1"></td>
        </tr>
        <tr>
            <td><input type="number" name="num2"></td>
        </tr>
        <tr>
             <td><input type="number" name="num3"></td>
         </tr>
        
        
        <tr>
            <td><input type="submit" name="submit" value="Suma"></td>
        </tr>
    </table>


</form>

</body>
</html>