<html>
  <head>
    <title>Pere Comments again </title>
  </head>
<body>
<?php
  echo "<h3>List</h3>
        <ul>
        <li>I've learnt to pass variables belong 2 files</li>
        <li>Also to use POST method with the forms</li>
        <li>Use type 'hidden' to pass values hidden </li>
        <li>The input submit could have value or not depends if the user click on it</li>
        <li>I've learnt to get values given by forms using POST on anothe or the same file</li>
        <li>With forms is possible to do a querie with the values given of an user</li>
        <li>Header() works to redirect </li>
        <li>With forms we can store values and use only on the action href</li>
        <li>To use date data on a mysqli with php We need use date('Y-m-d') to store correctly</li>
        <li>All the differents inputs type are usefull on php and mysql's use </li>
  
  </ul>
  <p>Document: 9</p>
  <p>Teacher: 10</p>
  <p>Myself: 10</p>
  <p>Improvemts: I don't know what improvements could make easier to learn this but I know that I would need improve myself in php. ";
?>
</body>
</html>