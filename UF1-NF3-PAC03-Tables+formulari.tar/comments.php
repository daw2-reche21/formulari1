<html>
  <head>
    <title>Pere Comments </title>
  </head>
<body>
<?php
  echo "<h3>List</h3>
        <ul>
        <li>I've learnt to pass variables belong the links with \$_GET</li>
        <li>There are different ways to write in html o mysql code with PHP, We can use <<<HTML or any name and write the code </li>
        <li>It's important to write gethostname() or localhost depends on We work on it </li>
        <li>The operator .= is for concatenate strings on variables</li>
        <li>The functions in php are usefull to get data and save in variables which We gonna use later </li>
        <li>On msqli_functions() of php always goes first the \$db and then the other data, separate with ',' </li>
        <li>It's possible to store html code in a php variable </li>
        <li>If We use GET variables then we can use it on mysql code to make queries dynamically</li>
        <li>I's necessary retrive the rows to show it up on html code</li>
        <li>Make an echo message after a query is important to know If It works </li>
  
  </ul>
  <p>Document: 5</p>
  <p>Teacher: 9</p>
  <p>Myself: 10</p>
  <p>Improvemts: I don't know what improvements could make easier to learn this but I know that I would need improve myself in php. ";
?>
</body>
</html>