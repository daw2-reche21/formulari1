<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="N4P113formprocess.php" method="post">
    <table>
        <tr>
        <td><input type="text" name="texto1"></td>
        </tr>
        <tr>
            <td><input type="text" name="texto2"></td>
        </tr>
        <tr>
             <td><input type="text" name="texto3"></td>
         </tr>
        <tr>
            <td><input type="text" name="texto4"></td>
         </tr>
        <tr>
            <td><input type="text" name="texto5"></td>
        </tr>
        <tr>
             <td><input type="text" name="texto6"></td>
        </tr>
         <tr>
            <td><input type="text" name="texto7"></td>
        </tr>
        <tr>
            <td><input type="submit" name="submit" value="submit"></td>
        </tr>
    </table>


</form>

</body>
</html>